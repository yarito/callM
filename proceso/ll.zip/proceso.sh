cd /home/callcenter/interfaz/proceso
/usr/bin/php totales.php
cd /home/callcenter/interfaz/procesar
mv a* ../auxiliar/
mv * ../procesados
mv ../auxiliar/* ./
gunzip *.gz
cd ../proceso
/usr/bin/php interfaz.php
/usr/bin/php ccext_contactogarantido_out.php
